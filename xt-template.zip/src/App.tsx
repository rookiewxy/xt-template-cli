/*
 * @Description: 
 * @Autor: wxy
 * @Date: 2021-07-03 09:21:15
 * @LastEditors: wxy
 * @LastEditTime: 2021-07-03 09:43:46
 */
import React from 'react';
import './App.css';
import BasicLayout from './layout/basic-layout';

function App() {
  return (
    <div className="App">
        <BasicLayout></BasicLayout>
    </div>
  );
}

export default App;
