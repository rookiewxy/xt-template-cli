import PageLeft from "./page-left";

export default PageLeft
