import PageIcon from "./page-icon";
import { PageIconGroup } from "./page-icon";

export default PageIcon
export {PageIconGroup}
