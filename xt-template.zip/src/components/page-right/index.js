import PageRight from "./page-right"

export default PageRight
