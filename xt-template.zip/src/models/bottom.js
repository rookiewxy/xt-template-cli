import { types } from "mobx-state-tree"

export const MBottom = types.model('MBottom',{

})
