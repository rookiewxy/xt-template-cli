/*
 * @Description: 
 * @Author: cxy
 * @Date: 2021-06-24 10:16:11
 * @LastEditors: cxy
 * @LastEditTime: 2021-07-08 15:13:11
 */
import './index.less'


const Foo = () => {
  

  return <>
    <div className="foo-page">
    </div>
  </>
}
export default Foo;
