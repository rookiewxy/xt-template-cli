const ue4c = window.Xt.ue4c;
export default ue4c;