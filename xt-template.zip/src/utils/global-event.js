import createEvent from "./event"

const globalEvent = createEvent()

window.globalEvent = globalEvent

export default globalEvent
