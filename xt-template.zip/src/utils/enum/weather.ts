enum Weather {
    CLEAR_SKIES,
    PARTLY_CLOUDY,
    CLOUDY,
    OVERCAST,
    FOGGY,
    LIGHT_RAIN,
    RAIN,
    THUNDERSTORM,
    LIGHT_SNOW,
    SNOW,
    BLIZZARD,
    SELECT_PRESET
}

export default Weather