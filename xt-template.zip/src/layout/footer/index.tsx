/*
 * @Description: 底部
 * @Autor: wxy
 * @Date: 2021-04-22 09:29:51
 * @LastEditors: wxy
 * @LastEditTime: 2021-08-09 10:47:49
 */
import { useEffect } from "react";
import "./index.less";

const Footer = () => {

  useEffect(() => {
  }, []);

  return (
    <>
    </>
  );
};

export default Footer;
